import java.io.IOException;

import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
@WebServlet("/student/adding")
public class Add_students extends HttpServlet {
    @Override
    public void doPost (HttpServletRequest req,HttpServletResponse res) throws IOException{
        String name = req.getParameter("name");
        String dept = req.getParameter("dept");
        if(name=="" || dept==""){
            res.getWriter().write("Student is Missing");
            return;
        }
        else{
            res.getWriter().write("Student Name is: "+name+" Dept is: "+dept);
        }
    }

}
