package com.example.Employees.service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Service;

import com.example.Employees.entity.EmployeesDetails;
@Service
public class EmployeeService {
    Map<Integer,EmployeesDetails> details = new HashMap<>();

    public EmployeesDetails saveData(EmployeesDetails var) {
        details.put(var.getId(),var);
        return var;       
    }

    public List<EmployeesDetails> GetAllEmployee() {
       return new ArrayList<>(details.values());
    }

    public EmployeesDetails getID(int id) {
       if(details.containsKey(id)){
        return details.get(id);
       }
       else{
        return null;
       }
    }

    public EmployeesDetails deleteID(int id) {
       return  details.remove(id);
    }

    
    
}
