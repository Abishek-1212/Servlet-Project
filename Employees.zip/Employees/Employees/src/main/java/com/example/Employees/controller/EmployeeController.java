package com.example.Employees.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.Employees.entity.EmployeesDetails;
import com.example.Employees.service.EmployeeService;
import org.springframework.web.bind.annotation.RequestBody;

@RestController
public class EmployeeController {
    @Autowired
    EmployeeService ser;
    @PostMapping("/post_Employee")
    public EmployeesDetails addEmployee(@RequestBody EmployeesDetails var){
        return ser.saveData(var);
    }
    @GetMapping("/GetallEmployee")
    public List<EmployeesDetails>GetallEmployee(){
        return ser.GetAllEmployee();
    }
    @GetMapping("/getElementByID/{id}")
    public EmployeesDetails getID(@PathVariable int id){
        return ser.getID(id);
    }
    @DeleteMapping("/DeleteByID/{id}")
    public EmployeesDetails deleteID(@PathVariable int id){
        return ser.deleteID(id);
    }
}
